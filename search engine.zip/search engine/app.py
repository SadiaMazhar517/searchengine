import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load data
with open("data.txt", "r", encoding="utf-8") as f:
    docs = [line.strip() for line in f.readlines() if line.strip()]

st.set_page_config(page_title="search", page_icon="🔍")
st.title("🔍 NLP Search Engine ")

# -----------------------------
# SESSION STATE
# -----------------------------
if "query" not in st.session_state:
    st.session_state.query = ""

# -----------------------------
# ALL WORDS FROM DATA
# -----------------------------
words = set()
for doc in docs:
    for w in doc.lower().split():
        words.add(w)

# -----------------------------
# INPUT BOX
# -----------------------------
input_text = st.text_input("Search here:", value=st.session_state.query)

st.session_state.query = input_text

# -----------------------------
# 🔥 SMART AUTOCOMPLETE (REAL DROP-DOWN FEEL)
# -----------------------------
suggestions = []

if input_text:
    suggestions = [w for w in words if input_text.lower() in w.lower()][:8]

# -----------------------------
# DROPDOWN STYLE SELECT
# -----------------------------
if suggestions:
    selected = st.selectbox(
        "Suggestions:",
        [""] + suggestions
    )

    if selected:
        st.session_state.query = selected
        input_text = selected

# -----------------------------
# 🔍 NLP SEARCH ENGINE
# -----------------------------
if input_text:

    corpus = docs + [input_text]

    vectorizer = TfidfVectorizer(stop_words="english")
    vectors = vectorizer.fit_transform(corpus)

    similarity = cosine_similarity(vectors[-1], vectors[:-1])[0]

    ranked = similarity.argsort()[::-1]

    st.markdown("### 📄 Results:")

    count = 0
    found = False

    for i in ranked:
        if similarity[i] > 0:
            count += 1
            st.success(f"{count}. {docs[i]} (score: {similarity[i]:.2f})")
            found = True

        if count == 5:
            break

    if not found:
        st.warning("No results found 😕")